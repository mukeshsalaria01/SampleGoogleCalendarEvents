﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI.WebControls;
using Google.Apis.Services;
using Google.Apis.Auth.OAuth2;
using System.Threading;


namespace ASPCalendarEvent
{
    public partial class ASPCalendarEvent : System.Web.UI.Page
    {
        public class CalendarEvents
        {
            public string Day { get; set; }
            public string Location { get; set; }
            public string Time { get; set; }
            public string Map { get; set; }
            public string Month { get; set; }
        }

        /// <summary>
        /// Get the google calendar events on page load.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            int days;
            int.TryParse(Request.QueryString["days"], out days);
            var credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                     new ClientSecrets
                     {
                         ClientId = "Client ID",
                         ClientSecret = "Secret Key",
                     },
                     new[] { Google.Apis.Calendar.v3.CalendarService.Scope.Calendar },
                     "user",
                     CancellationToken.None).Result;
            var service = new Google.Apis.Calendar.v3.CalendarService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential,
                ApplicationName = "Calendar API Sample",

            });

            var noOfDays = int.Parse(Request.QueryString["days"]);

            var eventList = service.Events.List("Calendar ID"); //put your google calender id, you can get it from your google calendar settings

            var calEvents = new List<CalendarEvents>();

            for (var i = 0; i < noOfDays; i++)
            {
                var minDate = DateTime.Now.AddDays(i);
                eventList.TimeMin = DateTime.Now.AddDays(i);
                eventList.TimeMax = DateTime.Now.AddDays(i + 1);

                var newList = eventList.Execute().Items;// check for each day having event or not

                if (newList.Count > 0)
                {
                    foreach (var newitem in newList)
                    {
                        var startTime = Convert.ToString(eventList.TimeMin);
                        var arrDateTime = startTime.Split('/');
                        var month = minDate.ToString("MMM");
                        var day = arrDateTime[1];
                        var arrYearTime = arrDateTime[2].Split(' ');
                        var startTimeSpan = arrYearTime[1];
                        var endDate = Convert.ToString(newitem.End.DateTime);
                        var arrEndDateTime = endDate.Split('/');
                        var arrEndYearTime = arrEndDateTime[2].Split(' ');
                        var endTimeSpan = arrEndYearTime[1] + arrEndYearTime[2];
                        var time = startTimeSpan + " - " + endTimeSpan;
                        var map = "https://www.google.com/maps?q=" + newitem.Location;
                        calEvents.Add(new CalendarEvents { Day = day, Time = time, Map = map, Location = newitem.Summary, Month =month });
                    }
                }
                else
                {
                    var startTime = Convert.ToString(eventList.TimeMin);
                    var arrDateTime = startTime.Split('/');
                    var month = minDate.ToString("MMM");
                    var day = arrDateTime[1];
                    calEvents.Add(new CalendarEvents { Day = day, Month = month, Location = "No Event Found!", Time = "N/A" });
                }
            }
            rptEvents.DataSource = calEvents;
            rptEvents.DataBind();
        }

    
    }
}